var a = [1, 1, 2, 2, 1];
var k=new Array(a.length-1).fill(0);
for(i=0;i<=a.length-2;i++)
{
for(j=i+1;j<=a.length-1;j++)
{
if(a[i]==a[j])
{
k[j]=a[j];
}
}
}
for(r=0;r<=k.length-1;r++)
 {
 if(k[r]!=0)
 {
 console.log("firstDuplicate(a)"+" "+"=" + " " +k[r]);
 process.exit();
 }

 }
 for(r=0;r<=k.length-1;r++)
 {
 if(k[r]==0)
 {
 console.log("firstDuplicate(a)"+" "+"=" + " " +-1);
 process.exit();
 }

 };
var k=new Array(a.length-1).fill(0);
for(i=0;i<=a.length-2;i++)
{
for(j=i+1;j<=a.length-1;j++)
{
if(a[i]==a[j])
{
k[j]=a[j];
}
}
}
for(r=0;r<=k.length-1;r++)
 {
 if(k[r]!=0)
 {
 console.log("firstDuplicate(a)"+" "+"=" + " " +k[r]);
 process.exit();
 }

 }
 for(r=0;r<=k.length-1;r++)
 {
 if(k[r]==0)
 {
 console.log("firstDuplicate(a)"+" "+"=" + " " +-1);
 process.exit();
 }

 }
